package com.example.myfirstapplication;

import static com.example.myfirstapplication.R.*;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Activity1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(layout.activity_1);
    }
}